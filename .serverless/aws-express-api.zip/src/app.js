"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const morgan_1 = __importDefault(require("morgan"));
const cors_1 = __importDefault(require("cors"));
const serverless_http_1 = __importDefault(require("serverless-http"));
const dictionaryController_1 = require("./controllers/dictionaryController");
const app = (0, express_1.default)();
app.use(express_1.default.json());
app.use((0, cors_1.default)());
morgan_1.default.token('body', (req) => JSON.stringify(req.body));
app.use((0, morgan_1.default)(':method :url :status :res[content-length] - :response-time ms :body'));
app.get('/:word', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    try {
        const word = req.params.word;
        let data = yield (0, dictionaryController_1.getWord)(word);
        let listOfWords;
        if (((_a = data.Items) === null || _a === void 0 ? void 0 : _a.length) === 0)
            throw new Error('Word not found');
        if (data.Count !== undefined && data.Count > 1) {
            listOfWords = (_b = data.Items) === null || _b === void 0 ? void 0 : _b.map((word) => {
                delete word['Definitions'];
                return word;
            });
        }
        else {
            listOfWords = data.Items;
        }
        res.send(data.Items);
    }
    catch (error) {
        console.log(error);
        res.status(404).send('Word not found');
    }
}));
app.get('/part-of-speech/:part', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const { letter } = req.query;
        const part = req.params.part;
        let data;
        if (!letter) {
            data = yield (0, dictionaryController_1.getWordByOnlyPos)(part);
        }
        else {
            data = yield (0, dictionaryController_1.getWordByPosAndLetter)(part, letter);
        }
        res.send(data);
    }
    catch (error) {
        console.log(error);
        res.status(404).send('Part not exist');
    }
}));
app.get('/:word/:pos', (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    var _c;
    try {
        const { word, pos } = req.params;
        let data = yield (0, dictionaryController_1.getWordByPos)(word, pos);
        if (((_c = data.Items) === null || _c === void 0 ? void 0 : _c.length) === 0)
            throw new Error('Word not found');
        res.send(data);
    }
    catch (error) {
        console.log(error);
        res.status(404).send('Word not found');
    }
}));
module.exports.handler = (0, serverless_http_1.default)(app);
//# sourceMappingURL=app.js.map