"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getWordByPos = exports.getWordByPosAndLetter = exports.getWordByOnlyPos = exports.getWord = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const REGION = 'eu-west-1';
const DynamoDBClient = new aws_sdk_1.default.DynamoDB.DocumentClient({ region: REGION });
const getWord = (word) => __awaiter(void 0, void 0, void 0, function* () {
    var params = {
        TableName: 'Dictionary',
        KeyConditionExpression: 'Word = :word ',
        ExpressionAttributeValues: {
            ':word': word,
        },
    };
    const data = yield DynamoDBClient.query(params).promise();
    return data;
});
exports.getWord = getWord;
const getWordByOnlyPos = (pos) => __awaiter(void 0, void 0, void 0, function* () {
    const params = {
        TableName: 'Dictionary',
        FilterExpression: 'Pos = :pos',
        ExpressionAttributeValues: { ':pos': pos + '.' },
    };
    const data = yield DynamoDBClient.scan(params).promise();
    if (data.Count && data.Items) {
        const num = Math.floor(Math.random() * data.Count);
        return data.Items[num];
    }
    throw data;
});
exports.getWordByOnlyPos = getWordByOnlyPos;
const getWordByPosAndLetter = (pos, letter) => __awaiter(void 0, void 0, void 0, function* () {
    const params = {
        TableName: 'Dictionary',
        ScanFilter: {
            Pos: {
                ComparisonOperator: 'EQ',
                AttributeValueList: [pos + '.'],
            },
            Word: {
                ComparisonOperator: 'BEGINS_WITH',
                AttributeValueList: [letter],
            },
        },
    };
    const data = yield DynamoDBClient.scan(params).promise();
    if (data.Count && data.Items) {
        const num = Math.floor(Math.random() * data.Count);
        return data.Items[num];
    }
    throw data;
});
exports.getWordByPosAndLetter = getWordByPosAndLetter;
const getWordByPos = (word, pos) => __awaiter(void 0, void 0, void 0, function* () {
    const params = {
        TableName: 'Dictionary',
        KeyConditionExpression: 'Word = :word and Pos = :pos ',
        ExpressionAttributeValues: {
            ':word': word,
            ':pos': pos + '.',
        },
    };
    const data = yield DynamoDBClient.query(params).promise();
    return data;
});
exports.getWordByPos = getWordByPos;
//# sourceMappingURL=dictionaryController.js.map